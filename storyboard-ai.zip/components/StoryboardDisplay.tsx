
import React from 'react';
import type { Scene } from '../types';
import { StoryboardPanel } from './StoryboardPanel';
import { Spinner } from './Spinner';
import { DownloadIcon, FilmIcon, WarningIcon } from './Icon';

// This is a browser-only feature, so we can use `window`
declare const jspdf: any;
declare const html2canvas: any;

interface StoryboardDisplayProps {
  storyboard: Scene[] | null;
  isLoading: boolean;
  error: string | null;
  progress: string;
  onUpdateScene: (scene: Scene) => void;
}

const WelcomeMessage: React.FC = () => (
  <div className="text-center text-gray-400 flex flex-col items-center justify-center h-full p-8">
    <FilmIcon className="w-24 h-24 text-gray-600 mb-4" />
    <h3 className="text-2xl font-semibold text-gray-300">Let's Create a Story</h3>
    <p className="mt-2 max-w-md">
      Enter your story, script, or idea in the control panel on the left, select your style, and click "Create Storyboard" to see the magic happen.
    </p>
  </div>
);

const ErrorDisplay: React.FC<{ message: string }> = ({ message }) => (
    <div className="text-center text-red-400 flex flex-col items-center justify-center h-full p-8 bg-red-900/20 rounded-lg">
        <WarningIcon className="w-16 h-16 text-red-500 mb-4" />
        <h3 className="text-xl font-semibold text-red-300">An Error Occurred</h3>
        <p className="mt-2 max-w-lg">{message}</p>
    </div>
);

export const StoryboardDisplay: React.FC<StoryboardDisplayProps> = ({
  storyboard,
  isLoading,
  error,
  progress,
  onUpdateScene,
}) => {
  const storyboardRef = React.useRef<HTMLDivElement>(null);

  const handleExportPDF = async () => {
    const { jsPDF } = jspdf;
    const storyboardElement = storyboardRef.current;
    if (!storyboardElement) return;

    try {
        const pdf = new jsPDF({
            orientation: 'landscape',
            unit: 'px',
            format: 'a4'
        });

        const panels = storyboardElement.querySelectorAll('.storyboard-panel-pdf');
        const pdfWidth = pdf.internal.pageSize.getWidth();
        const pdfHeight = pdf.internal.pageSize.getHeight();
        const margin = 20;

        for(let i=0; i<panels.length; i++) {
            const panel = panels[i] as HTMLElement;
            const canvas = await html2canvas(panel, {
                scale: 2,
                backgroundColor: '#1f2937', // Same as panel bg
            });
            const imgData = canvas.toDataURL('image/png');
            
            const imgWidth = pdfWidth - (margin * 2);
            const imgHeight = (canvas.height * imgWidth) / canvas.width;
            
            if (i > 0) {
              pdf.addPage();
            }
            
            pdf.addImage(imgData, 'PNG', margin, margin, imgWidth, imgHeight);
        }
        
        pdf.save('storyboard-ai.pdf');

    } catch(e) {
        console.error("Failed to export PDF", e);
        alert("Could not export to PDF. See console for details.");
    }
  };


  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-center p-8">
        <Spinner />
        <p className="mt-4 text-lg font-medium text-cyan-300">Generating Your Vision...</p>
        <p className="text-gray-400 mt-2">{progress}</p>
      </div>
    );
  }

  if (error) {
    return <ErrorDisplay message={error} />;
  }

  if (!storyboard || storyboard.length === 0) {
    return <WelcomeMessage />;
  }

  return (
    <div className="h-full flex flex-col">
        <div className="p-4 border-b border-gray-700 flex justify-between items-center">
            <h2 className="text-xl font-semibold">Generated Storyboard</h2>
            <button
                onClick={handleExportPDF}
                className="flex items-center bg-green-600 hover:bg-green-500 text-white font-bold py-2 px-4 rounded-lg transition duration-200"
            >
                <DownloadIcon className="w-5 h-5 mr-2" />
                Export PDF
            </button>
        </div>
        <div className="flex-grow overflow-y-auto p-4 md:p-6" ref={storyboardRef}>
            <div className="space-y-8">
            {storyboard.map((scene) => (
                <StoryboardPanel key={scene.sceneNumber} scene={scene} onUpdate={onUpdateScene} />
            ))}
            </div>
        </div>
    </div>
  );
};
