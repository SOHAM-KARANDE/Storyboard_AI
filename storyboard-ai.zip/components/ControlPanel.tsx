
import React from 'react';
import { GenerateIcon } from './Icon';

interface ControlPanelProps {
  story: string;
  setStory: (story: string) => void;
  style: string;
  setStyle: (style: string) => void;
  mood: string;
  setMood: (mood: string) => void;
  styles: string[];
  moods: string[];
  isLoading: boolean;
  onGenerate: () => void;
}

export const ControlPanel: React.FC<ControlPanelProps> = ({
  story,
  setStory,
  style,
  setStyle,
  mood,
  setMood,
  styles,
  moods,
  isLoading,
  onGenerate,
}) => {
  return (
    <div className="bg-gray-800/50 p-6 rounded-lg border border-gray-700 space-y-6 sticky top-24">
      <h2 className="text-xl font-semibold text-cyan-300">Creative Controls</h2>
      
      <div>
        <label htmlFor="story" className="block text-sm font-medium text-gray-300 mb-2">
          Your Story or Script
        </label>
        <textarea
          id="story"
          rows={10}
          className="w-full bg-gray-900/70 border border-gray-600 rounded-md p-3 text-gray-200 focus:ring-2 focus:ring-indigo-400 focus:border-indigo-400 transition duration-200 resize-y"
          placeholder="Paste your script, outline, or just describe a scene..."
          value={story}
          onChange={(e) => setStory(e.target.value)}
          disabled={isLoading}
        />
      </div>

      <div>
        <label htmlFor="style" className="block text-sm font-medium text-gray-300 mb-2">
          Imagery Style
        </label>
        <select
          id="style"
          className="w-full bg-gray-900/70 border border-gray-600 rounded-md p-3 text-gray-200 focus:ring-2 focus:ring-indigo-400 focus:border-indigo-400 transition duration-200"
          value={style}
          onChange={(e) => setStyle(e.target.value)}
          disabled={isLoading}
        >
          {styles.map((s) => (
            <option key={s} value={s}>{s}</option>
          ))}
        </select>
      </div>

      <div>
        <label htmlFor="mood" className="block text-sm font-medium text-gray-300 mb-2">
          Tone & Mood
        </label>
        <select
          id="mood"
          className="w-full bg-gray-900/70 border border-gray-600 rounded-md p-3 text-gray-200 focus:ring-2 focus:ring-indigo-400 focus:border-indigo-400 transition duration-200"
          value={mood}
          onChange={(e) => setMood(e.target.value)}
          disabled={isLoading}
        >
          {moods.map((m) => (
            <option key={m} value={m}>{m}</option>
          ))}
        </select>
      </div>

      <button
        onClick={onGenerate}
        disabled={isLoading}
        className="w-full flex items-center justify-center bg-indigo-600 hover:bg-indigo-500 disabled:bg-indigo-800 disabled:text-gray-400 disabled:cursor-not-allowed text-white font-bold py-3 px-4 rounded-lg transition duration-300 transform hover:scale-105"
      >
        <GenerateIcon className="w-5 h-5 mr-2" />
        {isLoading ? 'Generating...' : 'Create Storyboard'}
      </button>
    </div>
  );
};
