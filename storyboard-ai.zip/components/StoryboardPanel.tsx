
import React, { useState } from 'react';
import type { Scene } from '../types';

interface StoryboardPanelProps {
  scene: Scene;
  onUpdate: (scene: Scene) => void;
}

export const StoryboardPanel: React.FC<StoryboardPanelProps> = ({ scene, onUpdate }) => {
  const [notes, setNotes] = useState(scene.notes);

  const handleNotesChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setNotes(e.target.value);
  };
  
  const handleNotesBlur = () => {
    if (notes !== scene.notes) {
      onUpdate({ ...scene, notes });
    }
  };

  return (
    <div className="bg-gray-800 rounded-lg shadow-lg overflow-hidden border border-gray-700 storyboard-panel-pdf">
      <div className="p-4 border-b border-gray-700 bg-gray-900/50">
          <h3 className="text-lg font-bold text-cyan-300">
              Scene {scene.sceneNumber}: <span className="text-gray-300 font-medium">{scene.shotType}</span>
          </h3>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4">
        <div className="aspect-video bg-gray-900 rounded-md overflow-hidden flex items-center justify-center">
            <img 
                src={scene.imageUrl} 
                alt={scene.description} 
                className="w-full h-full object-cover" 
            />
        </div>
        <div className="space-y-3 text-sm flex flex-col">
            <div>
                <h4 className="font-semibold text-gray-400">Description</h4>
                <p className="text-gray-300">{scene.description}</p>
            </div>
            <div>
                <h4 className="font-semibold text-gray-400">Characters</h4>
                <p className="text-gray-300">{scene.characters.join(', ') || 'None specified'}</p>
            </div>
            <div className="flex-grow">
                <h4 className="font-semibold text-gray-400 mb-1">Notes</h4>
                <textarea
                    value={notes}
                    onChange={handleNotesChange}
                    onBlur={handleNotesBlur}
                    placeholder="Add director's notes, dialogue, or sound cues here..."
                    className="w-full h-full min-h-[80px] bg-gray-900/70 border border-gray-600 rounded-md p-2 text-gray-200 focus:ring-1 focus:ring-indigo-400 focus:border-indigo-400 transition duration-200"
                />
            </div>
        </div>
      </div>
    </div>
  );
};
