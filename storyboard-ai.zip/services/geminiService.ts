
import { GoogleGenAI, Type, GenerateContentResponse } from "@google/genai";
import type { Scene, SceneData } from "../types";

// Ensure this environment variable is set in your deployment environment
const API_KEY = process.env.API_KEY;
if (!API_KEY) {
  // In a real app, you might want to handle this more gracefully.
  // For this context, we assume the key is present.
  console.warn("API_KEY environment variable not set.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY! });

const sceneSchema = {
  type: Type.OBJECT,
  properties: {
    sceneNumber: { type: Type.INTEGER, description: "The sequential number of the scene, starting from 1." },
    description: { type: Type.STRING, description: "A short description of the main action, setting, and dialogue in the scene." },
    shotType: { type: Type.STRING, description: "The camera shot type (e.g., Wide Shot, Medium Shot, Close-up, POV, Over-the-shoulder)." },
    characters: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description: "A list of characters present in the scene."
    },
    imagePrompt: { type: Type.STRING, description: "A detailed, vivid prompt for an AI image generator to create the visual for this scene. This must include character descriptions, actions, emotions, and the environment." }
  },
  required: ['sceneNumber', 'description', 'shotType', 'characters', 'imagePrompt']
};

const storyboardSchema = {
  type: Type.ARRAY,
  items: sceneSchema
};

async function getSceneBreakdown(story: string, style: string, mood: string): Promise<SceneData[]> {
  const model = 'gemini-2.5-flash';
  const systemInstruction = `You are an expert screenplay analyst and storyboard director. Your task is to read the following story and break it down into a sequence of distinct visual scenes suitable for a storyboard.

For each scene, you must identify:
1. A brief description of the action and setting.
2. The shot type (e.g., Wide Shot, Medium Shot, Close-up).
3. The main characters involved.
4. A detailed, descriptive prompt for an AI image generator to create the visual for this scene. This prompt should be vivid and capture the essence of the scene, including character appearance, actions, emotions, and the environment.

The user has specified the overall visual style as "${style}" and the mood as "${mood}". Incorporate these elements directly into each generated image prompt.

The output must be a JSON array, where each object represents a scene according to the provided schema.`;

  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: model,
      contents: story,
      config: {
        systemInstruction: systemInstruction,
        responseMimeType: "application/json",
        responseSchema: storyboardSchema,
      },
    });

    const jsonText = response.text.trim();
    if (!jsonText) {
        throw new Error("API returned an empty response for scene breakdown.");
    }

    const scenes: SceneData[] = JSON.parse(jsonText);
    if (!Array.isArray(scenes) || scenes.length === 0) {
      throw new Error("Failed to generate a valid scene breakdown. The story might be too short or ambiguous.");
    }
    return scenes;
  } catch (error) {
    console.error("Error getting scene breakdown:", error);
    throw new Error(`Failed to analyze the story. ${error instanceof Error ? error.message : ''}`);
  }
}

async function generateImageForScene(imagePrompt: string): Promise<string> {
  const model = 'imagen-3.0-generate-002';
  try {
    const response = await ai.models.generateImages({
      model: model,
      prompt: imagePrompt,
      config: {
        numberOfImages: 1,
        outputMimeType: 'image/jpeg',
        aspectRatio: '16:9',
      },
    });

    const base64ImageBytes = response.generatedImages[0]?.image?.imageBytes;
    if (!base64ImageBytes) {
      throw new Error("Image generation failed, no image data returned.");
    }
    return `data:image/jpeg;base64,${base64ImageBytes}`;
  } catch (error) {
     console.error("Error generating image:", error);
     throw new Error(`Failed to generate image for prompt: "${imagePrompt.substring(0, 50)}...". ${error instanceof Error ? error.message : ''}`);
  }
}

export async function generateStoryboardFromText(
  story: string,
  style: string,
  mood: string,
  onProgress: (message: string) => void
): Promise<Scene[]> {
  onProgress('Analyzing script and breaking down scenes...');
  const sceneDataArray = await getSceneBreakdown(story, style, mood);
  
  onProgress(`Found ${sceneDataArray.length} scenes. Generating images... (0/${sceneDataArray.length})`);

  const storyboardPromises = sceneDataArray.map(async (sceneData, index) => {
    try {
        const imageUrl = await generateImageForScene(sceneData.imagePrompt);
        onProgress(`Found ${sceneDataArray.length} scenes. Generating images... (${index + 1}/${sceneDataArray.length})`);
        return {
            ...sceneData,
            imageUrl: imageUrl,
            notes: '',
        };
    } catch (e) {
        // Create a placeholder image if generation fails for a single scene
        console.error(`Failed to generate image for scene ${sceneData.sceneNumber}:`, e);
        onProgress(`Found ${sceneDataArray.length} scenes. Generating images... (${index + 1}/${sceneDataArray.length}) - Error with this scene.`);
        return {
            ...sceneData,
            imageUrl: `https://picsum.photos/seed/${sceneData.sceneNumber}/1280/720`,
            notes: `Image generation failed for this scene. Error: ${e instanceof Error ? e.message : 'Unknown error'}`,
        }
    }
  });

  const fullStoryboard = await Promise.all(storyboardPromises);
  return fullStoryboard.sort((a, b) => a.sceneNumber - b.sceneNumber);
}
